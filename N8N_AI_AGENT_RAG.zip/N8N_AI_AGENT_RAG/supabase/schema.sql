CREATE TABLE IF NOT EXISTS documents (
    id SERIAL PRIMARY KEY,
    chunk TEXT,
    context TEXT,
    embedding VECTOR(1536),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS meta_data (
    id SERIAL PRIMARY KEY,
    session_id TEXT UNIQUE,
    language TEXT,
    privacy_consent BOOLEAN,
    initial_scope TEXT,
    human_help BOOLEAN,
    successful_session BOOLEAN,
    created_at TIMESTAMP DEFAULT NOW()
);